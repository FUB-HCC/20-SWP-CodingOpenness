package de.rki.coronawarnapp.ui.submission

enum class ScanStatus {
    STARTED, INVALID, SUCCESS
}
