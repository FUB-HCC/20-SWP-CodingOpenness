package de.rki.coronawarnapp.exception

enum class ExceptionCategory { UI, SERVICE, HTTP, INTERNAL, JOB, EXPOSURENOTIFICATION, CONNECTIVITY }
