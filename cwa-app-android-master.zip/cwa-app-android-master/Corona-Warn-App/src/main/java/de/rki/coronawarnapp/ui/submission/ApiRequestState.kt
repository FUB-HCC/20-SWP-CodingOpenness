package de.rki.coronawarnapp.ui.submission

enum class ApiRequestState {
    IDLE, STARTED, FAILED, SUCCESS
}
