package de.rki.coronawarnapp.exception

class NoAuthCodeSetException : Exception("there is no valid auth code set in local storage")
