---
name: "\U0001F4AC Anything else?"
about: For conceptual questions, please consider to open an issue in the documentation repository.

---
<!--
Thanks for contributing to the project 🙌 ❤️

Before opening a new issue, please make sure that we do not have any duplicates already open. You can ensure this by searching the issue list for this repository. If there is a duplicate, please close your issue and add a comment to the existing issue instead.

Also, be sure to check our readme first: https://github.com/corona-warn-app/cwa-app-android
-->

* [ ] None of the other issue templates apply to this issue.
